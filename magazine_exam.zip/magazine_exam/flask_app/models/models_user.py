from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
import re
r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$'
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$') 

db = 'magazines_schema'


class User :
    def __init__(self , data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
    
    @classmethod
    def get_by_email(cls , data):
        query = 'select * from users where email = %(email)s'
        result =  connectToMySQL(db).query_db(query,data)
        if len(result) < 1:
            return False
        return cls(result[0])
    
    @classmethod
    def save(cls, data):
        query = 'insert  into users (first_name , last_name , email , password)  values (%(first_name)s  ,   %(last_name)s  ,   %(email)s  , %(password)s)'
        return connectToMySQL(db).query_db(query , data)
    
    @classmethod
    def get_one(cls, data):
        query = 'select * from users where id = %(id)s'
        results = connectToMySQL (db).query_db(query , data)
        users = []
        for user in results:
            users.append(user)
        return users
    
    @classmethod
    def updateaccount(cls,data):
        query = 'update users set first_name = %(first_name)s , last_name = %(last_name)s , email = %(email)s where id=%(id)s'
        return connectToMySQL(db).query_db(query,data)
    
    @staticmethod
    def validate_user(users):
        is_valid = True
        if len(users['first_name']) < 2  :
            flash("first_name must be at least 2 characters.")
            is_valid = False
        if len(users['last_name']) < 2  :
            flash("last_name must be at least 2 characters.")
            is_valid = False
        if len(users['email']) < 2 or len(users['email']) > 50 :
            flash("Email must be in email format.")
            is_valid = False
        if len(users['password']) < 1:
            flash("Please enter a password")
            is_valid = False
            
        return is_valid
    @staticmethod
    def validate_updated_user(users):
        is_valid = True
        if len(users['first_name']) < 2  :
            flash("first_name must be at least 2 characters.")
            is_valid = False
        if len(users['last_name']) < 2  :
            flash("last_name must be at least 2  characters.")
            is_valid = False
        if len(users['email']) < 2 or len(users['email']) > 50 :
            flash("Email must be in email format.")
            is_valid = False
            
        return is_valid

    
    
    
    
    
    
    
    
        
    @staticmethod
    def validate_user(users):
        is_valid = True
        if len(users['first_name']) < 2 or len(users['first_name']) > 50 :
            flash("first_name must be between 1 and 21  characters.")
            is_valid = False
        if len(users['last_name']) < 2 or len(users['last_name']) > 50 :
            flash("last_name must be between 1 and 21  characters.")
            is_valid = False
        if len(users['email']) < 2 or len(users['email']) > 50 :
            flash("Email must be in email format.")
            is_valid = False
        if len(users['password']) < 8 or len(users['password']) > 70:
            flash("password must be minimum of 8 characters")
            is_valid = False
            
        return is_valid

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    @staticmethod
    def validate_user(users):
        is_valid = True
        if len(users['first_name']) < 3 or len(users['first_name']) > 50 :
            flash("first_name must be between 2 and 21  characters.")
            is_valid = False
        if len(users['email']) < 3 or len(users['email']) > 50 :
            flash("Email must be in email format.")
            is_valid = False
        if len(users['password']) < 1:
            flash("Please enter a password")
            is_valid = False
            
        return is_valid    
    