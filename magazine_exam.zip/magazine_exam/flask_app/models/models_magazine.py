from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models.models_user import User
from flask import render_template,redirect,session,request,flash
db = 'magazines_schema'






class Magazine:
    def __init__(self , data):
        self.id = data['id']
        self.title = data['title']
        self.description = data['description']
        self.user_id = data['user_id']
        
        
    @classmethod
    def get_all(cls):
        query = """select * from magazines
        Join users ON users.id = magazines.user_id
        """
        results = connectToMySQL(db).query_db(query)
        users = []
        for user in results:
            writer = cls(user)
            user_data = {
            'id':user['id'],
            'first_name' :user['first_name'],
            'last_name':user['last_name'],
            'email':user['email'],
            'password':user['password']
            }
            writer.creator=User(user_data)
            users.append(writer)
        return users
    
    
    @classmethod
    def create(cls, data):
        query = "Insert into magazines (title , description , user_id) values ( %(title)s     ,    %(description)s , %(user_id)s )"
        return connectToMySQL(db).query_db(query , data)
    
    @classmethod
    def get_one(cls,data):
        query = 'Select * from magazines where id = %(id)s'
        results = connectToMySQL(db).query_db(query , data)
        magazines = []
        for magazine in results:
            magazines.append(magazine)
        return magazines
    
    @classmethod
    def update(cls,data):
        query = 'update magazines set title = %(title)s , description = %(description)s where id = %(id)s'
        return connectToMySQL(db).query_db(query,data)
    
    @classmethod
    def delete(cls,data):
        query = 'delete from magazines where id = %(id)s'
        return connectToMySQL(db).query_db(query , data)
    
    
    
    
        
    @staticmethod
    def validate_magazine(magazines):
        is_valid = True
        if len(magazines['title']) < 2  :
            flash("title must be at least 2 characters.")
            is_valid = False
        if len(magazines['description']) < 10  :
            flash("description must be at least 10 characters.")
            is_valid = False
            
        return is_valid

    
    
        

    
        