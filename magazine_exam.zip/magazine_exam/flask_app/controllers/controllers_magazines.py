from flask_app import app
from flask import render_template,redirect,session,request,flash
from flask_app.models.models_magazine import Magazine
from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models import models_user
from flask import flash





@app.route('/magazines')
def showall():
    if 'user_id' not in session:
        flash('must sign in first')
        return redirect ('/')
    magazines = Magazine.get_all()
    return render_template ('allmagazines.html'  , magazines=magazines)

@app.route('/magazines/new')
def create():
    if 'user_id' not in session:
        flash('must sign in first')
        return redirect ('/')
    return render_template('create.html')

@app.route('/shownewmagazines'  , methods = ['post'])
def shownewmagazines():
    data = {'title' : request.form['title']  ,  'description': request.form['description']   ,  'user_id':request.form['user_id']}
    Magazine.create(data)
    if 'user_id' not in session:
        flash('must sign in first')
        return redirect ('/')
    if not Magazine.validate_magazine(request.form):
        return redirect('/magazines/new')
    return redirect('/magazines')

@app.route('/magazines/<int:id>')
def get_one(id):
    data = {'id':id}
    magazine = Magazine.get_one(data)
    if 'user_id' not in session:
        flash('must sign in first')
        return redirect ('/')
    return render_template('showone.html' , magazine = magazine)

@app.route('/magazines/edit/<int:id>')
def edit(id):
    data = {'id':id}
    magazine = Magazine.get_one(data)
    if 'user_id' not in session:
        flash('must sign in first')
        return redirect ('/')
    return render_template('edit.html' , magazine = magazine)

@app.route('/magazines/update/<int:id>' , methods=['post'])
def update(id):
    data = {'title' : request.form['title']  ,  'description': request.form['description']   ,  'id':request.form['id']}
    Magazine.update(data)
    return redirect ('/magazines')

@app.route('/magazines/delete/<int:id>')
def delete(id):
    data = {'id':id}
    Magazine.delete(data)
    return redirect('/magazines')
    

@app.route('/reset')
def logout():
    session.clear()
    return redirect('/')
